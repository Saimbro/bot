# coding: utf-8
#
# Created by David Hargat.
# Copyright © 2017 Giphy. All rights reserved.
#
# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.
from __future__ import absolute_import

# import apis into api package
from .default_api import DefaultApi
